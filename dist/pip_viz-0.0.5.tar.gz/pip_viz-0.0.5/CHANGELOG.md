# pip-viz Changelog

## 0.0.1

- Initial version

## 0.0.2

- Fixed problem with duplicate notes

## 0.0.3

- Added graph attributes to make graph easier to read

## 0.0.4

- Made this package pip installable

## 0.0.5

- Refactored, added version numbers for packages.
- Added logging
- Created some tests

